package com.biascheck.biasdetector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiasDetectorApplication {

	public static void main(String[] args) {
		SpringApplication.run(BiasDetectorApplication.class, args);
	}

}
